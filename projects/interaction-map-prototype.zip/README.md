# Interaction Map

A small DDES1150 Interaction 1 prototype for Step 2: Map the interaction.

The tool is intended as a digital aid, not a replacement for manual mapping. It provides a persistent working table for recording:

- Human behaviour: Doing, Knowing, Feeling
- System behaviour: Input, Process, Output

## Use

Open `index.html` in a browser. Working is saved in the browser using local storage. Use **Map tools → My maps** to open, rename, duplicate, or delete maps in the current session.

The **Duplicate current map** button creates a separate named map in the same workspace. Maps appear as tabs in the mapping section and are not compared inside the tool. The × control on each tab provides a quick way to delete a map. **Print / Save PDF** exports every saved map one after another. **Export JSON** creates a portable backup of the complete local session, while **Import JSON** restores that backup.

The tool is intended as a digital aid, not a replacement for manual mapping. Browser data can be cleared or lost, so students should export JSON and PDF copies regularly.
